## ℹ️ Information
- Pack Name: Programmer Art Fix
- Author: [THGABS](https://modrinth.com/user/THGABS)
- Part of this pack is based on the work of others:
  - The painting "Baroque" is based on the work by Sarah Boeving.
  - The painting "Cotán" is based on the work by Kristoffer Zetterstrand.
  - The models of powered redstone comparator and repeater are made by muzikbike on [Mojira](https://bugs.mojang.com).

##  ©️ Copyright
- You CANNOT repost (part of) my resource pack to any other website, unless you are explicitly authorized.
  - When you are authorized to repost, you should always credit me as the author and provide original links to this pack.
- You MUST NOT use my work for any commercial purpose.
- Private uses, which means you've made something that would never be distributed to others, is not subject to these terms.
- Sharing this pack with your friends is okay.

## 🔗 Official Links
- Modrinth: <https://modrinth.com/resourcepack/programmer-art-fix>
- CurseForge: <https://www.curseforge.com/minecraft/texture-packs/programmer-art-fix>
